/* 
* File:   main.cpp
* Author: David Snow
*
* Created on June 25, 2014, 1:18 PM
*/
//system libraries
#include <iostream>
using namespace std;

//User Libraries

//Function Prototypes

//Global Constants

//Execution Begins Here
int main(int argc, char** argv) {
   //variables
   char let;//let is letter that is inputed
   cout << "Input a letter:";
   cin >> let;
   cout << "  " << let << let << let << "\n";
   cout << " " << let << "  " << let << "\n";
   cout << let << "\n";
   cout << let << "\n";
   cout << let << "\n";
   cout << let << "\n";
   cout << let << "\n";
   cout << " " << let << "  " << let << "\n";
   cout << "  " << let << let << let;
   return 0;
}