/* 
* File:   main.cpp
* Author: David Snow
*
* Created on June 25, 2014, 1:03 PM
*/
//system libraries
#include <iostream>
using namespace std;

//user libraries

//function prototypes

//global constants

//execution begins here
int main(int argc, char** argv) {
   cout << "******************************\n";
   cout << " \n";
   cout << "     CCC         SSSS      !!\n";
   cout << "    C   C       S    S     !!\n";
   cout << "   C           S           !!\n";
   cout << "  C             S          !!\n";
   cout << "  C              SSSS      !!\n";
   cout << "  C                  S     !!\n";
   cout << "   C                  S    !!\n";
   cout << "    C   C       S     S    \n";
   cout << "     CCC         SSSS      00\n";
   cout << " \n";
   cout << "******************************\n";
   return 0;
}
