/* 
 * File:   main.cpp
 * Author: David-Snow
 *
 * Created on June 23, 2014, 7:43 PM
 */
//System libraries
#include <iostream>
using namespace std;

//user libraries

//global constants

//function prototypes

//execution begins here

int main(int argc, char** argv) {
    //output simple text
    cout<<"Hello World"<<endl;
    return 0; 
}